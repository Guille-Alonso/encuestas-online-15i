const Footer = () => {
    return (
        <footer
    className={
        'bg-chatter-blue footer-height w-100 text-white d-flex align-items-center justify-content-center'
    }
    >
        <div className="px-5 text-center w-100">Todos los derechos reservados ® - Torem</div>
    </footer>
    );
}

export default Footer;
