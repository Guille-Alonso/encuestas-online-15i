const HomePage = () => {
    return (  
<div className="layout">
    <h1>Bienvenidos a la pagina principal de encuestas online</h1>
</div>
    );
}
 
export default HomePage;